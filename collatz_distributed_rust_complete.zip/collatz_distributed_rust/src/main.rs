use rayon::prelude::*;
use redis::{Commands, RedisResult};
use anyhow::Result;

fn collatz_steps(mut n: u64) -> u64 {
    let mut steps = 0;
    while n != 1 {
        n = if n % 2 == 0 { n / 2 } else { 3 * n + 1 };
        steps += 1;
    }
    steps
}

fn fetch_range() -> RedisResult<Option<(u64, u64)>> {
    let client = redis::Client::open("redis://redis/")?;
    let mut con = client.get_connection()?;
    let data: Option<String> = con.lpop("collatz_ranges")?;
    if let Some(entry) = data {
        let parts: Vec<&str> = entry.split(',').collect();
        if parts.len() == 2 {
            let start = parts[0].parse().ok()?;
            let end = parts[1].parse().ok()?;
            return Ok(Some((start, end)));
        }
    }
    Ok(None)
}

fn submit_result(n: u64, steps: u64) -> RedisResult<()> {
    let client = redis::Client::open("redis://redis/")?;
    let mut con = client.get_connection()?;
    let result = format!("{}:{}", n, steps);
    con.rpush("collatz_results", result)?;
    Ok(())
}

fn main() -> Result<()> {
    while let Some((start, end)) = fetch_range()? {
        println!("Processing range: {} - {}", start, end);
        (start..end).into_par_iter().for_each(|n| {
            let steps = collatz_steps(n);
            if steps > 500 {
                let _ = submit_result(n, steps);
            }
        });
    }
    Ok(())
}

use redis::Commands;

fn main() -> redis::RedisResult<()> {
    let client = redis::Client::open("redis://redis/")?;
    let mut con = client.get_connection()?;

    let chunk_size = 10000u64;
    let mut start = 1_000_000u64;
    let max = 1_100_000u64;

    while start < max {
        let end = start + chunk_size;
        let entry = format!("{},{}", start, end);
        con.rpush("collatz_ranges", entry)?;
        start = end;
    }
    println!("Work queue initialized.");
    Ok(())
}

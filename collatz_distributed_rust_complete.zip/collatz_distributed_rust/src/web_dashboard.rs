use actix_web::{web, App, HttpServer, Responder, HttpResponse};
use redis::Commands;

async fn get_top_results() -> impl Responder {
    let client = redis::Client::open("redis://redis/").unwrap();
    let mut con = client.get_connection().unwrap();
    let results: Vec<String> = con.lrange("collatz_results", -10, -1).unwrap_or_default();
    HttpResponse::Ok().body(format!("Recent: {:?}", results))
}

#[actix_web::main]
async fn main() -> std::io::Result<()> {
    HttpServer::new(|| {
        App::new().route("/", web::get().to(get_top_results))
    })
    .bind("0.0.0.0:8080")?
    .run()
    .await
}
